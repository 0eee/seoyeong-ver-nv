/*문진답변 받아오기*/
router.get('/form', (req, res) => {
 var immunity = req.params.immunity;
});

/*문진답변 post*/
Result=[]
router.post('/form', (req,res)=>{
  var immunity = req.params.immuity;
  var multiVitamin = true;
  var vitaminB = true;

  if(req.params.immunity1.length>2){
    result.push(multiVitamin)
    multiVitamin true;
  }
    res.render("result"{multiVitamin,vitaminB})
}});
