module.exports = function(app, conn){
  var express = require('express');
  var router = express.Router();

  /* root */
  router.get('/', (req, res) => {
    res.redirect('/news');
  });
  router.get('/generic', (req, res) => {
    res.render('news/generic');
  });
  router.get('/form', (req, res) => {
    res.render('news/form');
  });
  router.get('/elements', (req, res) => {
    res.render('news/elements');
  });
  router.get('/subscript10', (req, res) => {
    res.render('news/subscript10');
  });
  router.get('/subscript11', (req, res) => {
    res.render('news/subscript11');
  });
  router.get('/subscript30', (req, res) => {
    res.render('news/subscript30');
  });
  router.get('/subscript33', (req, res) => {
    res.render('news/subscript33');
  });
  router.get('/subscript60', (req, res) => {
    res.render('news/subscript60');
  });
  router.get('/subscript66', (req, res) => {
    res.render('news/subscript66');
  });
  router.get('/index', (req, res) => {
    res.render('news/index');
  });
  router.get('/landing-page', (req, res) => {
    res.render('news/landing-page');
  });
  router.get('/buy', (req, res) => {
    res.render('news/buy');
  });
  return router;
};
